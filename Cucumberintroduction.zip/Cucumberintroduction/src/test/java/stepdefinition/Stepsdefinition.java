package stepdefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.After;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import pageObjectModelExample.Loginpage;

public class Stepsdefinition {
	WebDriver driver;
	
	@Given("User landed on the homepage on dbank")
	public void user_landed_on_the_homepage_on_dbank() {
	   WebDriverManager.chromedriver().setup();
	   WebDriver driver = new ChromeDriver();
	   driver.manage().window().maximize();
	   driver.get("http://dbankdemo.com/login");
	    throw new io.cucumber.java.PendingException();
	}

	@When("user enters the crendtials {string} and {string}")
	public void user_enters_the_crendtials_and(String username, String password) {
		Loginpage login = new Loginpage(driver);
		  login.enterusername(username);
		  login.enterpassword(password);
		  login.submit();
		
	    throw new io.cucumber.java.PendingException();
	}

	@Then("user should be logged in successfully")
	public void user_should_be_logged_in_successfully() {
	    System.out.println("Logged in successfully");
	    throw new io.cucumber.java.PendingException();
	}
	
	@After
	public void complete() {
	driver.close();
	driver.quit();
}
}