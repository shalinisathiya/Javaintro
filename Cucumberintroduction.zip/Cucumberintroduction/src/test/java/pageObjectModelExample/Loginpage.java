package pageObjectModelExample;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Loginpage {
  WebDriver driver;
 public By name = By.id("username");
 public By pword =By.id("password");
 public By login =By.id("submit");
 public By image =By.xpath("//img[@alt='User Avatar']");
 public By logout =By.linkText("Logout");
  
  public Loginpage(WebDriver driver1) {
  driver=driver1;
  } 
  
  public void enterusername(String username) {
	  driver.findElement(name).sendKeys(username);
  }
  
  public void enterpassword(String password) {
	  driver.findElement(pword).sendKeys(password);
	 
  }
  
  public void submit() {
	  driver.findElement(login).click();
  }
  
  public void image1() {
	  driver.findElement(image).click();
  }
  
  public void logout1() {
	  driver.findElement(logout).click();
	  
  }
}


